(height, percentage, charging, low, color) 
{ 
/* just keep these */ 
var canvas = document.createElement("canvas"), 
context = canvas.getContext("2d"), 
tintOpaque = "rgba(" + color.join() + ",1)", 
barHeight = Math.round(height*0.43); 
barWidth = barHeight*0.38; 
canvas.width = barWidth; 
canvas.height = barHeight+2; 
context.fillStyle = "rgba(0,0,0,0.1)"; 
context.fillRect(0, 2, barWidth, barHeight); 
context.fillStyle = tintOpaque; 
if (percentage <= 20) {context.fillStyle = "#F00";} 
if (charging) {context.fillStyle = '#0F0';} 
context.fillRect(0, barHeight-Math.round(barHeight*(percentage/100))+2,barWidth,barHeight); 
return canvas.toDataURL("image/png"); 
}