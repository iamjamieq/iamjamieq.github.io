(height, percentage, charging, low, color)
{
var	fillHeight = Math.round(height*.4),
	barHeight = Math.round(height/2),
	barWidth = Math.round(height*1.125),
	radius = Math.round(height/15),
	rad = Math.round(radius/2),
	buffer = Math.round((barHeight-fillHeight)/2),
	width=Math.round(height*1.25),
	canvas = document.createElement("canvas"),
	context = canvas.getContext("2d"),
	tintOpaque = "rgb(" + color.join() + ")",
	imageData;
    canvas.width = width;
    canvas.height = height;
    context.lineWidth = Math.round(height/25);
    context.fillStyle = tintOpaque;

context.fillStyle = "#18453b";

context.beginPath();
context.arc(width*.269,height*.594,height*.306,0.722*Math.PI,Math.PI,false);
context.arc(width*.269,height*.406,height*.306,Math.PI,1.278*Math.PI,false);
context.arc(width*.5,height*.867,height*.847,1.278*Math.PI,1.722*Math.PI,false);
context.arc(width*.731,height*.406,height*.306,1.722*Math.PI,0,false);
context.arc(width*.731,height*.594,height*.306,0,0.278*Math.PI,false);
context.arc(width*.5,height*.133,height*.847,.278*Math.PI,.722*Math.PI,false);
context.fill();

context.globalCompositeOperation="xor";

context.beginPath();
context.arc(width*.5,height*.385,height*.3,Math.PI,0);
context.arc(width*.5,height*.615,height*.3,0,Math.PI);
context.lineTo(width*.5-height*.3,height*.385);
context.lineWidth = Math.floor(height / 20);
context.fill();
context.clearRect(width*(percentage/100),0,width,height);

context.globalCompositeOperation="source-over";
context.strokeStyle = "#fce122";

context.beginPath();
context.arc(width*.269,height*.594,height*.306,0.722*Math.PI,Math.PI);
context.arc(width*.269,height*.406,height*.306,Math.PI,1.278*Math.PI);
context.arc(width*.5,height*.867,height*.847,1.278*Math.PI,1.722*Math.PI);
context.arc(width*.731,height*.406,height*.306,1.722*Math.PI,0);
context.arc(width*.731,height*.594,height*.306,0,0.278*Math.PI);
context.arc(width*.5,height*.133,height*.847,.278*Math.PI,.722*Math.PI);
context.lineWidth = Math.floor(height / 20);
context.stroke();

context.globalCompositeOperation="source-over";
context.beginPath();
context.arc(width*.5,height*.385,height*.3,Math.PI,0);
context.arc(width*.5,height*.615,height*.3,0,Math.PI);
context.lineTo(width*.5-height*.3,height*.385);
context.lineWidth = Math.floor(height / 20);
context.stroke();

    return canvas.toDataURL("image/png");
}